//# sourceMappingURL=test.js.map
var process=process||{env:{NODE_ENV:"development"}};console.log("I AM CALLED");